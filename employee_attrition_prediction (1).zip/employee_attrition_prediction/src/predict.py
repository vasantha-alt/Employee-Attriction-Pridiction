"""
predict.py
----------
Load the trained model and predict attrition for new employee(s).

Usage examples:

1) Predict for a single employee (edit the sample dict below), run:
    python src/predict.py

2) Predict for a batch of employees stored in a CSV
   (with columns: Salary, JobSatisfaction, WorkLifeBalance, OverTime, YearsAtCompany):
    python src/predict.py --csv path/to/new_employees.csv
"""

import argparse
import pandas as pd
import joblib
import os

MODEL_PATH = os.path.join("models", "attrition_model.pkl")


def load_model():
    return joblib.load(MODEL_PATH)


def predict_single(model, salary, job_satisfaction, work_life_balance, overtime, years_at_company):
    sample = pd.DataFrame([{
        "Salary": salary,
        "JobSatisfaction": job_satisfaction,
        "WorkLifeBalance": work_life_balance,
        "OverTime": overtime,
        "YearsAtCompany": years_at_company
    }])
    pred = model.predict(sample)[0]
    proba = model.predict_proba(sample)[0][list(model.classes_).index("Yes")]
    return pred, proba


def predict_batch(model, csv_path):
    df = pd.read_csv(csv_path)
    preds = model.predict(df)
    probas = model.predict_proba(df)[:, list(model.classes_).index("Yes")]
    df["Predicted_Attrition"] = preds
    df["Attrition_Probability"] = probas.round(3)
    return df


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Predict employee attrition")
    parser.add_argument("--csv", type=str, help="Path to a CSV of new employees to score in batch")
    args = parser.parse_args()

    model = load_model()

    if args.csv:
        result_df = predict_batch(model, args.csv)
        out_path = "outputs/batch_predictions.csv"
        os.makedirs("outputs", exist_ok=True)
        result_df.to_csv(out_path, index=False)
        print(result_df)
        print(f"\nSaved batch predictions to {out_path}")
    else:
        # --- Example single-employee prediction (edit these values) ---
        sample_employee = dict(
            salary=42000,
            job_satisfaction=2,      # 1=Low, 2=Medium, 3=High, 4=Very High
            work_life_balance=1,     # 1=Bad, 2=Good, 3=Better, 4=Best
            overtime="Yes",
            years_at_company=1
        )

        pred, proba = predict_single(model, **sample_employee)
        print("Sample employee:", sample_employee)
        print(f"Predicted Attrition: {pred}")
        print(f"Probability of leaving: {proba:.2%}")
