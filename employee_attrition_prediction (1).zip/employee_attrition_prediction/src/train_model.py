"""
train_model.py
---------------
Loads the employee attrition dataset, preprocesses it, trains two models
(Logistic Regression and Random Forest), evaluates them, and saves the
best-performing model + preprocessing pipeline to models/attrition_model.pkl

Run:
    python src/train_model.py
"""

import os
import pandas as pd
import numpy as np
import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report, RocCurveDisplay
)

DATA_PATH = os.path.join("data", "employee_attrition.csv")
MODEL_PATH = os.path.join("models", "attrition_model.pkl")
OUTPUT_DIR = "outputs"

NUMERIC_FEATURES = ["Salary", "JobSatisfaction", "WorkLifeBalance", "YearsAtCompany"]
CATEGORICAL_FEATURES = ["OverTime"]
TARGET = "Attrition"


def load_data():
    df = pd.read_csv(DATA_PATH)
    return df


def build_preprocessor():
    numeric_transformer = StandardScaler()
    categorical_transformer = OneHotEncoder(drop="if_binary")

    preprocessor = ColumnTransformer(transformers=[
        ("num", numeric_transformer, NUMERIC_FEATURES),
        ("cat", categorical_transformer, CATEGORICAL_FEATURES),
    ])
    return preprocessor


def evaluate_model(name, model, X_test, y_test):
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, pos_label="Yes")
    rec = recall_score(y_test, y_pred, pos_label="Yes")
    f1 = f1_score(y_test, y_pred, pos_label="Yes")
    auc = roc_auc_score((y_test == "Yes").astype(int), y_proba)

    print(f"\n=== {name} ===")
    print(f"Accuracy : {acc:.3f}")
    print(f"Precision: {prec:.3f}")
    print(f"Recall   : {rec:.3f}")
    print(f"F1-score : {f1:.3f}")
    print(f"ROC-AUC  : {auc:.3f}")
    print(classification_report(y_test, y_pred))

    return {"name": name, "accuracy": acc, "precision": prec,
            "recall": rec, "f1": f1, "roc_auc": auc, "model": model}


def plot_eda(df):
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    sns.set_theme(style="whitegrid")

    fig, axes = plt.subplots(2, 3, figsize=(16, 9))

    sns.countplot(x="Attrition", data=df, ax=axes[0, 0], palette="Set2")
    axes[0, 0].set_title("Attrition Count")

    sns.boxplot(x="Attrition", y="Salary", data=df, ax=axes[0, 1], palette="Set2")
    axes[0, 1].set_title("Salary vs Attrition")

    sns.countplot(x="JobSatisfaction", hue="Attrition", data=df, ax=axes[0, 2], palette="Set2")
    axes[0, 2].set_title("Job Satisfaction vs Attrition")

    sns.countplot(x="WorkLifeBalance", hue="Attrition", data=df, ax=axes[1, 0], palette="Set2")
    axes[1, 0].set_title("Work-Life Balance vs Attrition")

    sns.countplot(x="OverTime", hue="Attrition", data=df, ax=axes[1, 1], palette="Set2")
    axes[1, 1].set_title("OverTime vs Attrition")

    sns.boxplot(x="Attrition", y="YearsAtCompany", data=df, ax=axes[1, 2], palette="Set2")
    axes[1, 2].set_title("Years at Company vs Attrition")

    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "eda_overview.png"), dpi=150)
    plt.close()
    print(f"Saved EDA plot to {OUTPUT_DIR}/eda_overview.png")


def plot_feature_importance(pipeline, feature_names):
    model = pipeline.named_steps["classifier"]
    if hasattr(model, "feature_importances_"):
        importances = model.feature_importances_
        order = np.argsort(importances)[::-1]

        plt.figure(figsize=(8, 5))
        sns.barplot(x=importances[order], y=np.array(feature_names)[order], palette="viridis")
        plt.title("Feature Importance (Random Forest)")
        plt.xlabel("Importance")
        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_DIR, "feature_importance.png"), dpi=150)
        plt.close()
        print(f"Saved feature importance plot to {OUTPUT_DIR}/feature_importance.png")


def plot_confusion(y_test, y_pred, name):
    cm = confusion_matrix(y_test, y_pred, labels=["No", "Yes"])
    plt.figure(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["No", "Yes"], yticklabels=["No", "Yes"])
    plt.title(f"Confusion Matrix - {name}")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "confusion_matrix.png"), dpi=150)
    plt.close()
    print(f"Saved confusion matrix to {OUTPUT_DIR}/confusion_matrix.png")


def main():
    df = load_data()
    print(f"Loaded dataset: {df.shape[0]} rows, {df.shape[1]} columns")
    plot_eda(df)

    X = df[NUMERIC_FEATURES + CATEGORICAL_FEATURES]
    y = df[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    preprocessor = build_preprocessor()

    # --- Model 1: Logistic Regression ---
    log_reg_pipeline = Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42))
    ])
    log_reg_pipeline.fit(X_train, y_train)
    result_lr = evaluate_model("Logistic Regression", log_reg_pipeline, X_test, y_test)

    # --- Model 2: Random Forest ---
    rf_pipeline = Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("classifier", RandomForestClassifier(
            n_estimators=300, max_depth=6, class_weight="balanced",
            random_state=42))
    ])
    rf_pipeline.fit(X_train, y_train)
    result_rf = evaluate_model("Random Forest", rf_pipeline, X_test, y_test)

    # Pick best model by ROC-AUC
    best = max([result_lr, result_rf], key=lambda r: r["roc_auc"])
    print(f"\n>>> Best model: {best['name']} (ROC-AUC = {best['roc_auc']:.3f})")

    # Save confusion matrix + feature importance for best model
    y_pred_best = best["model"].predict(X_test)
    plot_confusion(y_test, y_pred_best, best["name"])

    if best["name"] == "Random Forest":
        cat_names = list(
            best["model"].named_steps["preprocessor"]
            .named_transformers_["cat"].get_feature_names_out(CATEGORICAL_FEATURES)
        )
        feature_names = NUMERIC_FEATURES + cat_names
        plot_feature_importance(best["model"], feature_names)

    # Save the winning pipeline (preprocessing + model together)
    os.makedirs("models", exist_ok=True)
    joblib.dump(best["model"], MODEL_PATH)
    print(f"\nSaved best model pipeline to {MODEL_PATH}")

    # Save a small metrics summary
    summary = pd.DataFrame([{k: v for k, v in r.items() if k != "model"}
                             for r in [result_lr, result_rf]])
    summary.to_csv(os.path.join(OUTPUT_DIR, "model_comparison.csv"), index=False)
    print(f"Saved model comparison table to {OUTPUT_DIR}/model_comparison.csv")


if __name__ == "__main__":
    main()
