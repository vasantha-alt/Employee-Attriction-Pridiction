"""
generate_data.py
-----------------
Generates a synthetic (but realistically-correlated) employee attrition
dataset and saves it to data/employee_attrition.csv

Features:
    - Salary               (monthly salary in USD)
    - JobSatisfaction       (1-4 scale: 1=Low, 4=Very High)
    - WorkLifeBalance       (1-4 scale: 1=Bad, 4=Excellent)
    - OverTime              (Yes/No)
    - YearsAtCompany        (integer, 0-40)

Target:
    - Attrition             (Yes/No) - whether the employee left the company
"""

import numpy as np
import pandas as pd
import os

np.random.seed(42)

N = 1500  # number of employee records

def generate_dataset(n=N):
    salary = np.random.normal(loc=60000, scale=20000, size=n).clip(20000, 200000).round(-2)
    job_satisfaction = np.random.choice([1, 2, 3, 4], size=n, p=[0.15, 0.25, 0.35, 0.25])
    work_life_balance = np.random.choice([1, 2, 3, 4], size=n, p=[0.15, 0.30, 0.35, 0.20])
    overtime = np.random.choice(["Yes", "No"], size=n, p=[0.30, 0.70])
    years_at_company = np.random.exponential(scale=5, size=n).clip(0, 40).round().astype(int)

    # Build an underlying "risk score" that logically drives attrition
    # Lower salary, lower satisfaction, poor work-life balance, overtime=Yes,
    # and fewer years at company -> higher chance of leaving.
    risk_score = (
        -0.00003 * salary
        - 0.55 * job_satisfaction
        - 0.45 * work_life_balance
        + 0.9 * (overtime == "Yes").astype(int)
        - 0.06 * years_at_company
        + np.random.normal(0, 0.6, size=n)   # noise
    )

    # Convert risk score to probability via sigmoid, then sample Attrition
    prob_leave = 1 / (1 + np.exp(-(risk_score + 2.0)))
    attrition = np.where(np.random.rand(n) < prob_leave, "Yes", "No")

    df = pd.DataFrame({
        "Salary": salary.astype(int),
        "JobSatisfaction": job_satisfaction,
        "WorkLifeBalance": work_life_balance,
        "OverTime": overtime,
        "YearsAtCompany": years_at_company,
        "Attrition": attrition
    })
    return df


if __name__ == "__main__":
    df = generate_dataset()
    os.makedirs("data", exist_ok=True)
    out_path = os.path.join("data", "employee_attrition.csv")
    df.to_csv(out_path, index=False)
    print(f"Saved {len(df)} records to {out_path}")
    print(df["Attrition"].value_counts(normalize=True))
