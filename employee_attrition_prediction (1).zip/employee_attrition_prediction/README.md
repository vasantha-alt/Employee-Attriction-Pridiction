# Employee Attrition Prediction

A complete, ready-to-run machine learning project that predicts whether an
employee is likely to resign, based on:

- **Salary**
- **Job Satisfaction** (1 = Low ... 4 = Very High)
- **Work-Life Balance** (1 = Bad ... 4 = Excellent)
- **OverTime** (Yes / No)
- **Years at Company**

## Project Structure

```
employee_attrition_prediction/
├── data/
│   ├── employee_attrition.csv        # training dataset (1500 records)
│   └── new_employees_sample.csv      # sample file for batch predictions
├── models/
│   └── attrition_model.pkl           # trained pipeline (preprocessing + model)
├── outputs/
│   ├── eda_overview.png              # exploratory data analysis charts
│   ├── confusion_matrix.png
│   ├── feature_importance.png        # (if Random Forest wins)
│   ├── model_comparison.csv          # metrics for both models
│   └── batch_predictions.csv         # example batch output
├── src/
│   ├── generate_data.py              # creates the synthetic dataset
│   ├── train_model.py                # EDA + preprocessing + training + evaluation
│   └── predict.py                    # load model & predict (single or batch)
├── requirements.txt
└── README.md
```

## Setup

```bash
pip install -r requirements.txt
```

## How to Run

### 1. (Optional) Regenerate the dataset
```bash
python src/generate_data.py
```

### 2. Train the model
```bash
python src/train_model.py
```
This will:
- Run EDA and save charts to `outputs/`
- Train a **Logistic Regression** model and a **Random Forest** model
- Print accuracy, precision, recall, F1-score, and ROC-AUC for both
- Save the best-performing model to `models/attrition_model.pkl`

### 3. Make predictions

**Single employee** (edit the `sample_employee` dict inside `src/predict.py`):
```bash
python src/predict.py
```

**Batch prediction from a CSV**:
```bash
python src/predict.py --csv data/new_employees_sample.csv
```
Results are saved to `outputs/batch_predictions.csv`.

## Approach

1. **Data**: A synthetic dataset of 1,500 employees was generated with a
   realistic relationship between the five input features and attrition —
   lower salary, lower job satisfaction, poor work-life balance, working
   overtime, and fewer years at the company all increase resignation risk
   (with added randomness so it isn't a trivial rule).
2. **Preprocessing**: Numeric features are standardized; the categorical
   `OverTime` feature is one-hot encoded. Everything is wrapped in a
   scikit-learn `Pipeline` so the same steps apply automatically at
   prediction time.
3. **Modeling**: Two classifiers are trained and compared —
   Logistic Regression (interpretable baseline) and Random Forest
   (captures non-linear interactions). Both use `class_weight="balanced"`
   since attrition is a minority class (~13% of employees).
4. **Evaluation**: Accuracy, precision, recall, F1, and ROC-AUC are
   reported, since accuracy alone is misleading on imbalanced data.
   The model with the higher ROC-AUC is saved as the final model.

## Notes / Next Steps

- Replace `data/employee_attrition.csv` with your real HR dataset (keep the
  same column names) and re-run `train_model.py` to train on real data.
- To improve recall further, try adjusting the classification threshold
  (default is 0.5) in `predict.py`, or use techniques like SMOTE.
- Additional features that often help in real datasets: department, job
  role, distance from home, promotion history, and manager relationship.
